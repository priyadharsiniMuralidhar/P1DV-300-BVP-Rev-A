// Place this snippet in the script section
document.getElementById("age").focus()