// Place this snippet in the script section
document.getElementById("email").focus()

// Toggle password field visibility
document.getElementById("togglepwd").addEventListener('click', function (e) {
    let pwdField = document.getElementById("password");

    if (pwdField.type === 'password') {
        pwdField.type = 'text'
        e.currentTarget.classList.remove("fa-eye");
        e.currentTarget.classList.add("fa-eye-slash");
    } else {
        pwdField.type = 'password'
        e.currentTarget.classList.remove("fa-eye-slash");
        e.currentTarget.classList.add("fa-eye");
    }
});