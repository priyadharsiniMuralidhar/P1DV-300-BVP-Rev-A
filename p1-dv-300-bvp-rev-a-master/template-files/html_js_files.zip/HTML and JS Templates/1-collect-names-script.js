// Place this snippet in the script section
document.getElementById("fname").focus()